
/*
$('#make').click(function(){
    var data_set = "./" + $('#file')[0].files[0].name
    //D3.jsで書くときは書きを使用する。
    //var svg = d3.select("svg")
    d3.csv(
        data_set, function(data_set){
            console.log(data_set["TANIGUCHIJUNMemoryAvailableMBytes"]);
            var n = data_set.length;
            str_start_time = data_set[0]["(PDH-CSV4.0)("].substr(6, 4) + "/" + data_set[0]["(PDH-CSV4.0)("].substr(0, 5) + " " + data_set[0]["(PDH-CSV4.0)("].substr(-12);
            str_end_time = data_set[n-1]["(PDH-CSV4.0)("].substr(6, 4) + "/" + data_set[n-1]["(PDH-CSV4.0)("].substr(0, 5) + " " + data_set[n-1]["(PDH-CSV4.0)("].substr(-12);
            console.log(str_start_time);
            console.log(str_end_time);
            time_start = new Date(str_start_time);
            time_end = new Date(str_end_time);

            // グラフ(x, y)の範囲
            var xScale = d3.time.scale()
                            .domain([time_start, time_end])
                            .range([0, 1000]);
            var yScale = d3.scale.linear()
                            .range([5000, 0])
                            //.nice();
            
            var timestamp_list = [];
            var counterlog_list = [];

            // 折れ線グラフの線を作成
            var line = d3.svg.line()
                .x(function(d,i){
                    var tmp = new Date(d["(PDH-CSV4.0)("].substr(6, 4) + "/" + d["(PDH-CSV4.0)("].substr(0, 5) + " " + d["(PDH-CSV4.0)("].substr(-12));
                    //console.log(tmp);
                    timestamp_list.push(tmp);
                    return xScale(tmp);
                })
                .y(function(d,i){
                    //console.log(d["TANIGUCHIJUNMemoryAvailableMBytes"]);
                    counterlog_list.push(d["TANIGUCHIJUNMemoryAvailableMBytes"]);
                    return yScale(d["TANIGUCHIJUNMemoryAvailableMBytes"]);      
                })
                .interpolate("cardinal");
            
            var data_frame = [];
            data_frame.push(timestamp_list, counterlog_list);
           
            // 折れ線グラフを生成
            svg.append("path")
                .attr("d", line(timestamp_list, counterlog_list))
                .style("stroke", "red")
                .style("fill", "none");
            
            // グラフ(x, y)の軸
            var xAxis = d3.svg.axis()
                            .scale(xScale)
                            .orient("bottom");
            
            // x軸を描画
            svg.append("g")
                .attr({
                    class: "axis",
                    transform: "translate(0, 480)"
                })
                .call(d3.svg
                        .axis()
                        .scale(xScale)
                        .orient("bottom")
                        .tickFormat(function(d,i){
                            var fmtFunc = d3.time.format("%H:%M:%S");
                            return fmtFunc(d);
                        })
                )
                .selectAll("text")
                .attr("transform", "rotate(45)")
                .attr("dy", 10)
                .attr("dx", 10)
                .style("text-anchor", "start");
            // y軸を描画
            svg.append("g")
                .attr({
                    class: "axis",
                    transform: "translate(10, 0)"
                })
                .call(d3.svg.axis()
                .scale(yScale)
                .orient("left")
                );
            
        }

    )
    console.log(data_set);
    var csv = $.csv()(data_set);
    console.log(csv);
});
*/
$('#make').click(function(){
    var csvList;
    $.ajax({
        url: $('#file')[0].files[0].name,
        success: function(data) {
 
            // csvを配列に格納
            csvList = $.csv()(data);
            //グラフのx軸を定義
            var xScale = [];
            //console.log(csvList[1][0]);
            for(var i = 1; i < csvList.length; i++){
                /*
                var hour = Number(csvList[i][0].substr(10, 3));
                if(hour > 12){
                    hour = String(hour - 12);
                    var ampm = "PM";
                }else{
                    var hour = String(hour);
                    var ampm = "AM";
                }
                
                
                xScale.push(csvList[i][0].substr(6, 4) + "-" + //年
                            csvList[i][0].substr(0, 2) + "-" + //月
                            csvList[i][0].substr(3, 2) + " " + //日
                            csvList[i][0].substr(10, 8) +      //時間(HH:MM:SS)
                            //csvList[i][0].substr(19, 3) +      //時間(.00)
                            ampm
                            );
                */
                
                var year =  Number(csvList[i][0].substr(6, 4))
                var month = Number(csvList[i][0].substr(0, 2))
                var day =   Number(csvList[i][0].substr(3, 2))
                var hour =  Number(csvList[i][0].substr(10, 2))
                var minute = Number(csvList[i][0].substr(13, 2))
                var second = Number(csvList[i][0].substr(16, 2))
                var milisecond = Number(csvList[i][0].substr(19, 3))
                var timestamp = new Date(year, month, day, hour, minute, second);
                xScale.push(timestamp);
                /*
                var year =  csvList[i][0].substr(6, 4)
                var month = csvList[i][0].substr(0, 2)
                var day =   csvList[i][0].substr(3, 2)
                var hour =  csvList[i][0].substr(10, 2)
                var minute = csvList[i][0].substr(13, 2)
                var second = csvList[i][0].substr(16, 2)
                var milisecond = csvList[i][0].substr(19, 3)
                var timestamp =   year  + "-"
                                + month + "-"
                                + Date  + " "
                                + hour  + ":"
                                + minute;
                xScale.push(timestamp);
                console.log(timestamp);
                */
            }
            start_time = xScale[0];
            end_time =   xScale[xScale.length -1];
            //console.log(start_time);
            //console.log(end_time);
            //グラフのy軸を定義
            var yScale = [];
            for(var i = 1; i < csvList.length; i++){
                if (csvList[i][595] == ''){
                    csvList[i][595] = 0;
                }
                yScale.push(Number(csvList[i][595]));
            }
            var data_frame = [];

            for(var i = 0; i < csvList.length - 1; i++){
                data_frame[i] = [];
                data_frame[i][0] = xScale[i];
                data_frame[i][1] = yScale[i];
                /*
                var row_frame = [];
                row_frame.push(xScale[i]);
                row_frame.push(yScale[i]);
                console.log(row_frame);
                data_frame[i].push(row_frame);
                */
            }
            //console.log(data_frame);
            jQuery(function(){
                jQuery.jqplot(
                    'DiskTime',
                    [
                        data_frame
                        //[ [ '2012-01-01 0:00AM', 65 ], [ '2012-02-01 0:00AM', 96 ], [ '2012-03-01 0:00AM', 74 ], [ '2012-04-01 0:00AM', 63 ], [ '2012-05-01 0:00AM', 85 ], [ '2012-06-01 0:00AM', 90 ] ]
                    ],
                    {
                        axes:{
                            xaxis:{
                                renderer: jQuery.jqplot.DateAxisRenderer
                                ,min: start_time
                                ,max: end_time
                                //,tickInterval: '1 second'
                                ,tickOptions:{
                                    formatString: '%T'
                                },
                            }
                        },
                        cursor:{
                            show: true,
                            showTooltip: true,
                            followMouse: true,
                            zoom: true
                        },
                        series:[
                            {label: 'PhysicalDisk(_Total)%DiskTime'}
                        ],
                        legend:{
                            show: true,
                            placement: 'outside',
                            location: 'ne',
                        }
                    }
                );
            });
            console.log("finish");
            
        }
    });
});