
$('#make').click(function(){
    var csvList;
    $.ajax({
        url: $('#file')[0].files[0].name,
        success: function(data) {
            // csvを配列に格納
            csvList = $.csv()(data);
            dataplot(csvList, 595, 'DiskTime', 'PhysicalDisk(_Total)%DiskTime');
            dataplot(csvList, 396, 'MemoryPages_sec', 'MemoryPages/sec');
            dataplot(csvList, 619, 'Avg_DiskQueueLength', 'PhysicalDisk(_Total)Avg.DiskQueueLength');
            dataplot(csvList, 555, 'CurrentDiskQueueLength', 'PhysicalDisk(_Total)CurrentDiskQueueLength');
            dataplot(csvList, 547, 'DiskWrites_sec', 'PhysicalDisk(_Total)DiskWrites/sec');
            dataplot(csvList, 467, 'ProcessorProcessorTime', 'Processor(_Total)%ProcessorTime');
            dataplot(csvList, 3048, 'ProcessProcessorTime', 'Process(_Total)%ProcessorTime');
            dataplot(csvList, 457, 'UserTime', 'Processor(_Total)%UserTime');
            dataplot(csvList, 447, 'InterruptTime', 'Processor(_Total)%InterruptTime');

            console.log("finish");
        }
    });
});

function dataplot(csvList, counter_id, plot_id,counter_name){
   //グラフのx軸を定義
   var xScale = [];
   //console.log(csvList[1][0]);
   for(var i = 1; i < csvList.length; i++){              
       var year =  Number(csvList[i][0].substr(6, 4))
       var month = Number(csvList[i][0].substr(0, 2))
       var day =   Number(csvList[i][0].substr(3, 2))
       var hour =  Number(csvList[i][0].substr(10, 2))
       var minute = Number(csvList[i][0].substr(13, 2))
       var second = Number(csvList[i][0].substr(16, 2))
       var milisecond = Number(csvList[i][0].substr(19, 3))
       var timestamp = new Date(year, month, day, hour, minute, second);
       xScale.push(timestamp);
   }
   start_time = xScale[0];
   end_time =   xScale[xScale.length -1];
   //グラフのy軸を定義
   var yScale = [];
   for(var i = 1; i < csvList.length; i++){
       if (csvList[i][counter_id] == ''){
           csvList[i][counter_id] = 0;
       }
       yScale.push(Number(csvList[i][counter_id]));
   }
   var data_frame = [];

   for(var i = 0; i < csvList.length - 1; i++){
       data_frame[i] = [];
       data_frame[i][0] = xScale[i];
       data_frame[i][1] = yScale[i];
   }
   //console.log(data_frame);
   jQuery(function(){
       jQuery.jqplot(
           plot_id,
           [
               data_frame
           ],
           {
               title: counter_name,
               axes:{
                   xaxis:{
                       renderer: jQuery.jqplot.DateAxisRenderer
                       ,min: start_time
                       ,max: end_time
                       ,tickOptions:{
                           formatString: '%T'
                       },
                   }
               },
               cursor:{
                   show: true,
                   showTooltip: true,
                   followMouse: true,
                   showVerticalLine: true,
                   showHorizontalLine: true,
               },
               series:[
                   {label: counter_name}
               ],
               seriesDefaults:{
                   rendererOptions:{
                       smooth: true,
                       linewidth: 0.5
                   }
               },
               legend:{
                   show: true,
                   placement: 'outside',
                   location: 'ne',
               }
           }
       );
   });
};