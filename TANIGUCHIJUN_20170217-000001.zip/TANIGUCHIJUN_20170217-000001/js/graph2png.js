
$('#download').click(function(){
    
    var url = $("#DiskTime").jqplotToImageStr();
    $("body").append($("<img>").attr("id","DiskTimeImage"));
    $("#DiskTimeImage").attr("src",url);
    console.log(1111);
});